cnum = [
  0100
  0200
  0300
  0400
  0500
  0600
  0700
  0800
  0900
  1000
  1100
  1200
  1300
  1400
  1500
  1600
  1700
  1800
  1900
  2000
  2100
  2200
  2500
  3500
];

cname = [
  'Dairy and Egg Products           ',
  'Spices and Herbs                 ',
  'Baby Foods                       ',
  'Fats and Oils                    ',
  'Poultry Products                 ',
  'Soups, Sauces, and Gravies       ',
  'Sausages and Luncheon Meats      ',
  'Breakfast Cereals                ',
  'Fruits and Fruit Juices          ',
  'Pork Products                    ',
  'Vegetables and Vegetable Products',
  'Nut and Seed Products            ',
  'Beef Products                    ',
  'Beverages                        ',
  'Finfish and Shellfish Products   ',
  'Legumes and Legume Products      ',
  'Lamb, Veal, and Game Products    ',
  'Baked Products                   ',
  'Sweets                           ',
  'Cereal Grains and Pasta          ',
  'Fast Foods                       ',
  'Meals, Entrees, and Sidedishes   ',
  'Snacks                           ',
  'Ethnic Foods                     ',
  ];